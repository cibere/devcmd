# devcmd
 a developer tool for discord.py discord bots